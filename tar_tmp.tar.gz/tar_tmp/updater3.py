#!/usr/bin/env python

from __future__ import print_function

import chainer
import chainer.functions as F
from chainer import Variable

import numpy as np
from PIL import Image

from chainer import cuda
from chainer import function
from chainer.utils import type_check
import numpy
import time

EPS = 1e-12

class FacadeUpdater(chainer.training.StandardUpdater):

	def __init__(self, *args, **kwargs):
		self.gen, self.dis = kwargs.pop('models')
		super(FacadeUpdater, self).__init__(*args, **kwargs)

	def loss_gen(self, gen, x_out, t_out, y_fake, l1_weight=100, gan_weight=1):
		# gen_loss_GAN = tf.reduce_mean(-tf.log(predict_fake + EPS))
		# gen_loss_L1 = tf.reduce_mean(tf.abs(targets - outputs))
		# gen_loss = gen_loss_GAN * a.gan_weight + gen_loss_L1 * a.l1_weight
		batchsize,_,w,h = y_fake.data.shape
		loss_gan = F.sum(-(F.log(y_fake + EPS))) / batchsize / w / h
		loss_l1  = F.mean_absolute_error(x_out, t_out)
		loss = loss_gan * gan_weight + loss_l1 * l1_weight
		# loss_rec = lam1*(F.mean_absolute_error(x_out, t_out))
		# loss_adv = lam2*F.sum(F.softplus(-y_fake)) / batchsize / w / h
		# loss = loss_rec + loss_adv
		chainer.report({'loss': loss}, gen)
		return loss

	def loss_dis(self, dis, y_real, y_fake):
		# loss = tf.reduce_mean(-(tf.log(predict_real + EPS) + tf.log(1 - predict_fake + EPS)))
		batchsize,_,w,h = y_real.data.shape
		loss = F.sum(-(F.log(y_real + EPS) + F.log(1 - y_fake + EPS))) / batchsize / w / h
		# L1 = F.sum(F.softplus(-y_real)) / batchsize / w / h
		# L2 = F.sum(F.softplus( y_fake)) / batchsize / w / h
		# loss = L1 + L2
		chainer.report({'loss': loss}, dis)
		return loss

	def update_core(self):
		gen_optimizer = self.get_optimizer('gen') # 2.4 - 3.1 sec @ThinkPad X1
		dis_optimizer = self.get_optimizer('dis') #

		gen, dis = self.gen, self.dis # 1.4 - 1.9 sec @ThinkPad X1
		xp = gen.xp                   #

		batch = self.get_iterator('main').next()
		batchsize = len(batch)
		in_ch  = batch[0][0].shape[0]
		out_ch = batch[0][1].shape[0]
		w_in  = 256
		w_out = 256
	
		x_in  = xp.zeros((batchsize, in_ch,  w_in,  w_in)).astype("f")
		t_out = xp.zeros((batchsize, out_ch, w_out, w_out)).astype("f")

		for i in range(batchsize):
			x_in[i,:] = xp.asarray(batch[i][0])
			t_out[i,:] = xp.asarray(batch[i][1])

		x_in = Variable(x_in)       # 2.7 - 3.1 sec @ThinkPad X1
	
		x_out = gen(x_in)           # 0.18 sec @ ThinkPad X1

		y_fake = dis(x_in, x_out)   # 0.13 sec @ ThinkPad X1
		y_real = dis(x_in, t_out)   #

		gen_optimizer.update(self.loss_gen, gen, x_out, t_out, y_fake)

		x_in.unchain_backward()
		x_out.unchain_backward()

		dis_optimizer.update(self.loss_dis, dis, y_real, y_fake)

