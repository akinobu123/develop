#!/usr/bin/env python

from __future__ import print_function
import argparse
import os

import chainer
from chainer import training
from chainer.training import extensions
from chainer import serializers
import numpy as np
from PIL import Image
import time
import onnx_chainer

from net3 import Discriminator
from net3 import Generator

def main():
	time1 = time.time()

	parser = argparse.ArgumentParser(description='chainer implementation of pix2pix')
	parser.add_argument('--batchsize', '-b', type=int, default=1,
		                help='Number of images in each mini-batch')
	parser.add_argument('--epoch', '-e', type=int, default=200,
		                help='Number of sweeps over the dataset to train')
	parser.add_argument('--gpu', '-g', type=int, default=-1,
		                help='GPU ID (negative value indicates CPU)')
	parser.add_argument('--out', '-o', default='result',
		                help='Directory to output the result')
	parser.add_argument('--gen-npz', default='', required=True)
	parser.add_argument('input')
	args = parser.parse_args()

    # Set up a neural network to train
	with chainer.using_config('use_ideep', 'auto'):  # ideep
#	if True:
		time2 = time.time()

		gen = Generator(out_ch=3)
		print(gen)
		xp = gen.xp

		time3 = time.time()

		chainer.serializers.load_npz(args.gen_npz, gen)

		time4 = time.time()

		gen.to_intel64()  # ideep

		# load image and predict
		time5 = time.time()

		label = Image.open(args.input)
		w,h = label.size
		r = 286 / float(min(w,h))
		# resize images so that min(w, h) == 286
		label = label.resize((int(r*w), int(r*h)), Image.BILINEAR)
		w,h = label.size
		label_ = np.asarray(label) -1  # [0, 12)
		label = np.zeros((12, h, w)).astype("i")
		for j in range(12):
			label[j,:] = label_==j
		_,h,w = label.shape
		x_l = np.random.randint(0,w-256)
		x_r = x_l+256
		y_l = np.random.randint(0,h-256)
		y_r = y_l+256
		x_in = xp.zeros((1, 12, 256, 256)).astype("f")
		x_in[0,:] = xp.asarray(label[:,y_l:y_r,x_l:x_r])
		
		time6 = time.time()

		x = chainer.Variable(x_in)
		y = gen(x) # (batchsize, ch, width, height)

		time7 = time.time()
		print ("argument parse         : ", time2 - time1)
		print ("build model            : ", time3 - time2)
		print ("load pre-trained model : ", time4 - time3)
		print ("convert ideep variable : ", time5 - time4)
		print ("load image             : ", time6 - time5)
		print ("inference              : ", time7 - time6)

		y = y.data.reshape(3, 256, 256).transpose(1, 2, 0) # (width, height, ch) (-1..1)
		y = (y + 1.0) / 2.0 # (0..1)
		y = y.clip(0, 1)

		import matplotlib.pyplot as plt
		plt.imshow(y)
		plt.show()
		if False:
			import scipy.misc
			scipy.misc.imsave("output.png", y)

		chainer.config.train = False
		onnx_model = onnx_chainer.export(gen, x, filename='p2p.onnx')


if __name__ == '__main__':
	main()
