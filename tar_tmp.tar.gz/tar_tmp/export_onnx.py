import numpy as np
import chainer
import chainer.links as L
import onnx_chainer
from net3 import Generator


# ネットワークに流し込む擬似的なデータを用意する
x_in = np.zeros((1, 12, 256, 256)).astype("f")

# 推論モードにする
chainer.config.train = False

gen = Generator(out_ch=3)

onnx_model = onnx_chainer.export(gen, x_in, filename='p2p.onnx')
