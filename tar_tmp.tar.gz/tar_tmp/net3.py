#!/usr/bin/env python

from __future__ import print_function

import numpy

import chainer
from chainer import cuda
import chainer.functions as F
import chainer.links as L

# U-net https://arxiv.org/pdf/1611.07004v1.pdf

class Generator(chainer.Chain):
	def __init__(self, out_ch):
		super(Generator, self).__init__()
		with self.init_scope():
			w = chainer.initializers.Normal(0.02)
			self.enc_conv1 = L.Convolution2D(None,   64, 4, stride=2, pad=1, initialW=w)
			self.enc_conv2 = L.Convolution2D(None,  128, 4, stride=2, pad=1, initialW=w)
			self.enc_conv3 = L.Convolution2D(None,  256, 4, stride=2, pad=1, initialW=w)
			self.enc_conv4 = L.Convolution2D(None,  512, 4, stride=2, pad=1, initialW=w)
			self.enc_conv5 = L.Convolution2D(None,  512, 4, stride=2, pad=1, initialW=w)
			self.enc_conv6 = L.Convolution2D(None,  512, 4, stride=2, pad=1, initialW=w)
			self.enc_conv7 = L.Convolution2D(None,  512, 4, stride=2, pad=1, initialW=w)
			self.enc_conv8 = L.Convolution2D(None,  512, 4, stride=2, pad=1, initialW=w)
			self.enc_bn2   = L.BatchNormalization(128)
			self.enc_bn3   = L.BatchNormalization(256)
			self.enc_bn4   = L.BatchNormalization(512)
			self.enc_bn5   = L.BatchNormalization(512)
			self.enc_bn6   = L.BatchNormalization(512)
			self.enc_bn7   = L.BatchNormalization(512)
			self.enc_bn8   = L.BatchNormalization(512)
			self.dec_decv1 = L.Deconvolution2D(None,   512, 4, stride=2, pad=1, initialW=w)
			self.dec_decv2 = L.Deconvolution2D(None,   512, 4, stride=2, pad=1, initialW=w)
			self.dec_decv3 = L.Deconvolution2D(None,   512, 4, stride=2, pad=1, initialW=w)
			self.dec_decv4 = L.Deconvolution2D(None,   512, 4, stride=2, pad=1, initialW=w)
			self.dec_decv5 = L.Deconvolution2D(None,   256, 4, stride=2, pad=1, initialW=w)
			self.dec_decv6 = L.Deconvolution2D(None,   128, 4, stride=2, pad=1, initialW=w)
			self.dec_decv7 = L.Deconvolution2D(None,    64, 4, stride=2, pad=1, initialW=w)
			self.dec_decv8 = L.Deconvolution2D(None,out_ch, 4, stride=2, pad=1, initialW=w)
			self.dec_bn1   = L.BatchNormalization(512)
			self.dec_bn2   = L.BatchNormalization(512)
			self.dec_bn3   = L.BatchNormalization(512)
			self.dec_bn4   = L.BatchNormalization(512)
			self.dec_bn5   = L.BatchNormalization(256)
			self.dec_bn6   = L.BatchNormalization(128)
			self.dec_bn7   = L.BatchNormalization(64)

	def __call__(self, x):							# N, C, H, W
		enc_layer1 = self.enc_conv1 (x)             # 256 -> 128 pix
		enc_layer1 = F.leaky_relu   (enc_layer1)

		enc_layer2 = self.enc_conv2 (enc_layer1)    # 128 ->  64 pix
		enc_layer2 = self.enc_bn2   (enc_layer2)
		enc_layer2 = F.leaky_relu   (enc_layer2, 0.2)

		enc_layer3 = self.enc_conv3 (enc_layer2)    #  64 ->  32 pix
		enc_layer3 = self.enc_bn3   (enc_layer3)
		enc_layer3 = F.leaky_relu   (enc_layer3, 0.2)

		enc_layer4 = self.enc_conv4 (enc_layer3)    #  32 ->  16 pix
		enc_layer4 = self.enc_bn4   (enc_layer4)
		enc_layer4 = F.leaky_relu   (enc_layer4, 0.2)

		enc_layer5 = self.enc_conv5 (enc_layer4)    #  16 ->   8 pix
		enc_layer5 = self.enc_bn5   (enc_layer5)
		enc_layer5 = F.leaky_relu   (enc_layer5, 0.2)

		enc_layer6 = self.enc_conv6 (enc_layer5)    #   8 ->   4 pix
		enc_layer6 = self.enc_bn6   (enc_layer6)
		enc_layer6 = F.leaky_relu   (enc_layer6, 0.2)

		enc_layer7 = self.enc_conv7 (enc_layer6)    #   4 ->   2 pix
		enc_layer7 = self.enc_bn7   (enc_layer7)
		enc_layer7 = F.leaky_relu   (enc_layer7, 0.2)

		enc_layer8 = self.enc_conv8 (enc_layer7)    #   2 ->   1 pix
		enc_layer8 = self.enc_bn8   (enc_layer8)
		enc_layer8 = F.leaky_relu   (enc_layer8, 0.2)

		dec_layer1 = self.dec_decv1 (enc_layer8)    #   1 ->   2 pix
		dec_layer1 = self.dec_bn1   (dec_layer1)
		dec_layer1 = F.dropout      (dec_layer1, 0.5)
		dec_layer1 = F.relu         (dec_layer1)

		dec_layer2 = F.concat       ([dec_layer1, enc_layer7])
		dec_layer2 = self.dec_decv2 (dec_layer2)    #   2 ->   4 pix
		dec_layer2 = self.dec_bn2   (dec_layer2)
		dec_layer2 = F.dropout      (dec_layer2, 0.5)
		dec_layer2 = F.relu         (dec_layer2)

		dec_layer3 = F.concat       ([dec_layer2, enc_layer6])
		dec_layer3 = self.dec_decv3 (dec_layer3)    #   4 ->   8 pix
		dec_layer3 = self.dec_bn3   (dec_layer3)
		dec_layer3 = F.dropout      (dec_layer3, 0.5)
		dec_layer3 = F.relu         (dec_layer3)

		dec_layer4 = F.concat       ([dec_layer3, enc_layer5])
		dec_layer4 = self.dec_decv4 (dec_layer4)    #   8 ->  16 pix
		dec_layer4 = self.dec_bn4   (dec_layer4)
		dec_layer4 = F.relu         (dec_layer4)

		dec_layer5 = F.concat       ([dec_layer4, enc_layer4])
		dec_layer5 = self.dec_decv5 (dec_layer5)    #  16 ->  32 pix
		dec_layer5 = self.dec_bn5   (dec_layer5)
		dec_layer5 = F.relu         (dec_layer5)

		dec_layer6 = F.concat       ([dec_layer5, enc_layer3])
		dec_layer6 = self.dec_decv6 (dec_layer6)    #  32 ->  64 pix
		dec_layer6 = self.dec_bn6   (dec_layer6)
		dec_layer6 = F.relu         (dec_layer6)

		dec_layer7 = F.concat       ([dec_layer6, enc_layer2])
		dec_layer7 = self.dec_decv7 (dec_layer7)    #  64 -> 128 pix
		dec_layer7 = self.dec_bn7   (dec_layer7)
		dec_layer7 = F.relu         (dec_layer7)

		dec_layer8 = F.concat       ([dec_layer7, enc_layer1])
		dec_layer8 = self.dec_decv8 (dec_layer8)    # 128 -> 256 pix
		dec_layer8 = F.tanh         (dec_layer8)

		return dec_layer8



class Discriminator(chainer.Chain):
	def __init__(self):
		super(Discriminator, self).__init__()
		with self.init_scope():
			w = chainer.initializers.Normal(0.02)
			self.conv1_1 = L.Convolution2D(None, 32,  4, stride=2, pad=1, initialW=w)
			self.conv1_2 = L.Convolution2D(None, 32,  4, stride=2, pad=1, initialW=w)
			self.conv2   = L.Convolution2D(None, 128, 4, stride=2, pad=1, initialW=w)
			self.conv3   = L.Convolution2D(None, 256, 4, stride=2, pad=1, initialW=w)
			self.conv4   = L.Convolution2D(None, 512, 4, stride=1, pad=1, initialW=w)
			self.conv5   = L.Convolution2D(None, 1,   4, stride=1, pad=1, initialW=w)
			self.bn2     = L.BatchNormalization(128)
			self.bn3     = L.BatchNormalization(256)
			self.bn4     = L.BatchNormalization(512)

	def __call__(self, x_1, x_2):		# N, C, H, W
		layer1_1 = self.conv1_1(x_1)
		layer1_1 = F.leaky_relu(layer1_1, 0.2)

		layer1_2 = self.conv1_2(x_2)
		layer1_2 = F.leaky_relu(layer1_2, 0.2)

		layer1 = F.concat      ([layer1_1, layer1_2])

		layer2 = self.conv2    (layer1)
		layer2 = self.bn2      (layer2)
		layer2 = F.leaky_relu  (layer2, 0.2)

		layer3 = self.conv3    (layer2)
		layer3 = self.bn3      (layer3)
		layer3 = F.leaky_relu  (layer3, 0.2)

		layer4 = self.conv4    (layer3)
		layer4 = self.bn4      (layer4)
		layer4 = F.leaky_relu  (layer4, 0.2)

		layer5 = self.conv5    (layer4)
		layer5 = F.sigmoid     (layer5)

		return layer5

