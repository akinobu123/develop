#!/usr/bin/env python

# python train_facade.py -g 0 -i ./facade/base --out result_facade --snapshot_interval 10000

from __future__ import print_function
import argparse
import os

import chainer
from chainer import training
from chainer.training import extensions
from chainer import serializers

from net3 import Discriminator
from net3 import Generator
from updater3 import FacadeUpdater

from facade_dataset import FacadeDataset
from facade_visualizer3 import out_image

def main():
	parser = argparse.ArgumentParser(description='chainer implementation of pix2pix(ver3)')
	parser.add_argument('--batchsize', '-b', type=int, default=1,
						help='Number of images in each mini-batch')
	parser.add_argument('--epoch', '-e', type=int, default=200,
						help='Number of sweeps over the dataset to train')
	parser.add_argument('--gpu', '-g', type=int, default=-1,
						help='GPU ID (negative value indicates CPU)')
	parser.add_argument('--dataset', '-i', default='./facade/base',
						help='Directory of image files.')
	parser.add_argument('--out', '-o', default='result',
						help='Directory to output the result')
	parser.add_argument('--resume', '-r', default='',
						help='Resume the training from snapshot')
	parser.add_argument('--seed', type=int, default=0,
						help='Random seed')
	parser.add_argument('--snapshot_interval', type=int, default=10000,
						help='Interval of snapshot')
	parser.add_argument('--display_interval', type=int, default=100,
						help='Interval of displaying log to console')
	args = parser.parse_args()

	print('GPU: {}'.format(args.gpu))
	print('# Minibatch-size: {}'.format(args.batchsize))
	print('# epoch: {}'.format(args.epoch))
	print('')

	with chainer.using_config('use_ideep', 'auto'):  # ideep
#	if True:  # if not ideep
		# Set up a neural network to train
		gen = Generator(out_ch=3)
		dis = Discriminator()

		gen.to_intel64()  # ideep
		dis.to_intel64()  # ideep
		
		if args.gpu >= 0:
			chainer.cuda.get_device(args.gpu).use()  # Make a specified GPU current
			gen.to_gpu()
			dis.to_gpu()

		# Setup an optimizer
		def make_optimizer(model, alpha=0.0002, beta1=0.5):
			optimizer = chainer.optimizers.Adam(alpha=alpha, beta1=beta1)
			optimizer.setup(model)
			optimizer.add_hook(chainer.optimizer.WeightDecay(0.00001), 'hook_dec')
			return optimizer
		opt_gen = make_optimizer(gen)
		opt_dis = make_optimizer(dis)

		train_d = FacadeDataset(args.dataset, data_range=(1,300))
		test_d = FacadeDataset(args.dataset, data_range=(300,379))
		#train_iter = chainer.iterators.MultiprocessIterator(train_d, args.batchsize, n_processes=4)
		#test_iter = chainer.iterators.MultiprocessIterator(test_d, args.batchsize, n_processes=4)
		train_iter = chainer.iterators.SerialIterator(train_d, args.batchsize)
		test_iter = chainer.iterators.SerialIterator(test_d, args.batchsize)

		# Set up a trainer
		updater = FacadeUpdater(
			models=(gen, dis),
			iterator={
				'main': train_iter,
				'test': test_iter},
			optimizer={
				'gen': opt_gen,
				'dis': opt_dis},
			device=args.gpu)
		trainer = training.Trainer(updater, (args.epoch, 'epoch'), out=args.out)

		snapshot_interval = (args.snapshot_interval, 'iteration')
		display_interval = (args.display_interval, 'iteration')
		trainer.extend(
			extensions.snapshot(filename='snapshot_iter_{.updater.iteration}.npz'),
			trigger=snapshot_interval)
		trainer.extend(
			extensions.snapshot_object(gen, 'gen_iter_{.updater.iteration}.npz'), 
			trigger=snapshot_interval)
		trainer.extend(
			extensions.snapshot_object(dis, 'dis_iter_{.updater.iteration}.npz'), 
			trigger=snapshot_interval)
		trainer.extend(extensions.LogReport(trigger=display_interval))
		trainer.extend(
			extensions.PrintReport(['epoch', 'iteration', 'gen/loss', 'dis/loss',]), 
			trigger=display_interval)
		trainer.extend(extensions.ProgressBar(update_interval=10))
		trainer.extend(
			out_image(updater, gen, 5, 5, args.seed, args.out, args.gpu),
			trigger=snapshot_interval)

		if args.resume:
			# Resume from a snapshot
			chainer.serializers.load_npz(args.resume, trainer)

		# Run the training
		trainer.run()

if __name__ == '__main__':
	main()
